"""japanize-noto-sans-jp: Google Noto Sans JP 超軽量サブセットフォント自動設定モジュール"""

import os
import matplotlib
from matplotlib import font_manager

FONT_DIR = os.path.dirname(__file__)
FONT_FILE = os.path.join(FONT_DIR, "fonts", "NotoSansJP-Subset.otf")
FONT_NAME = "Noto Sans JP"


def japanize() -> None:
    """Noto Sans JP サブセットフォントを登録し、Matplotlib のフォントおよび SVG 設定を適用"""
    if os.path.exists(FONT_FILE):
        if hasattr(font_manager.fontManager, "addfont"):
            font_manager.fontManager.addfont(FONT_FILE)
        try:
            font_prop = font_manager.FontProperties(fname=FONT_FILE)
            name = font_prop.get_name()
        except Exception:
            name = FONT_NAME
        matplotlib.rc("font", family=[name, "Noto Sans JP", "sans-serif"])

    # SVG 描画時は文字をパス化せず <text> として出力し、Electron側のネイティブ描画エンジンに委ねる
    matplotlib.rcParams["svg.fonttype"] = "none"


japanize()
